<?php //00863
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2015 KBKP Software S.C. All Rights Reserved.
//  Version 2015-05-04
//  2015-05-04
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPufoQbprsMwKbCN/L7yfLTkaPeqb3GmqVCmKuLl5IU2p8KLCpmwOpGgUQ2/K/Q3wOUaa5AdL
7PnOHOzE9YkQ+2OHIVzNzMAjqGElsCMjR1jGVidw8422GCp7DmfL8Xl4cos/Y1c/TCJqx1LZHDSR
tXxTNA6ZRoak0vYyUmxUYbIISiLZdkhALZFRaMxNNuidnPAxDTtMNygLCF08NpTcL28U7ap+1KRP
qGghbyyNkfupYck+DmfRAbNkz8CS2ktgyFN478bEoNv+b68XhE6i0fHfvOxJ9OwBxbSdINYcDbGv
3aI1S/ZYc8Z7ltiwv3ZosiU2yIiMoGpoShQHNXdPtL+Sbn943mMoZlm2dcz7yFfj+KMzVOJ89tqo
O7IB5BSAzrbcN1BGCvECUSG8TbRsCuG78On9TR4UfbJUEcMiVqOwCmW5+66L/kD26wxljAgCvaR7
kRiYfrOUgG4f/3HDTxoaMsUkHda+1WIbQGz2XoxlK/2v/Hr4lST0I9zd4QFMw8a3+uxSt3xPVC9s
DLrF2jjiddejFeV5E4aKgZ2jAZatrOiMIfFNqLN7sCmGl/mc/3SFLNNc7TJ64D6hYME1qFk+aoHD
UR0WOgoUma+taqtin/rYYEMYbbFSvU7mz14UBNGUD//jYN39EG4bOuXl0mcul+Evc4hvx5HCu139
zyws2Nt+T4C5mgT/3N3GmZJYtYDhySlOQ9Vrj+mTthtYglHmx41syCeAa1BX5JFR/l05aCK61d3o
hWzQS6bXin5QnfLIKY7Ffovfd2MG1w1HmKOhJbDld3YhhnVVtiZ76jD9b4TjQyx2p2EhWMIGqdB7
SzncAqcWTTSSHQUrWUG61kpnqZfS8xJWL37peMyn1SqsH/lo0xySmYOqmI+UuCnM0FOac1oRgFYu
5ES6XyDx1iO/xIjR5gzEo5/CAeHQmBLLG4FSr1lh4a9CNYBdHl6+O0Cu8gDr1zokJJN07dwRhXsk
gTmtIZ1YT1BUX6B90urTZ6wwX3Z8/QeHKdtNH/CA/PpJb1rOjaqZc9JFXkyJE+Xo4v5WwqUQMDe0
uGlGQyMBmaIY4I0xoGDhCOSw910VhFudnNi=